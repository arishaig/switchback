"""Switchback - Solar-based dynamic wallpaper switcher for hyprpaper."""

__version__ = "1.1.1"
